printplaat revisie 20180719 0.7.03

<img src="https://github.com/pappavis/EasyLab-retro-synth-SN76489/blob/master/KiCAD/SN76489%20arduino%20nano%20shield/plaatje/EasyLabMuziek%20editie_SN76489_3d_pcb_voor.png?raw=true" width="50%" height="50%">

<br/>
<br/>
<img src="https://github.com/pappavis/EasyLab-retro-synth-SN76489/blob/master/KiCAD/SN76489%20arduino%20nano%20shield/plaatje/EasyLabMuziek%20editie_SN76489_klaar.jpg?raw=true" width="50%" height="50%"><br/>
