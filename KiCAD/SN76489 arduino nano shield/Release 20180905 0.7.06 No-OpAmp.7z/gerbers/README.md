printplaat 20180602 0.6

<img src="https://github.com/pappavis/EasyLab-retro-synth-SN76489/blob/master/KiCAD/SN76489%20arduino%20nano%20shield/plaatje/EasyLabMuziek%20editie_SN76489_pcb_0.5_voor.png?raw=true" width="50%" height="50%">
