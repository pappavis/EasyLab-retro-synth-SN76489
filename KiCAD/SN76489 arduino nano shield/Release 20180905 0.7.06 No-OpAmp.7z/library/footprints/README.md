footprints is die PCB weergawe van componenten.
