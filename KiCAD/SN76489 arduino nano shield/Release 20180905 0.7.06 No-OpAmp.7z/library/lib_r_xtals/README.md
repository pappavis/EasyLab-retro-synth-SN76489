dit is component bibliotheke wat jy gebruik in die Schema Editor.
