Biblioteke in gebruik met die shield. Daar is ook 'n paar oorbodig ;).
